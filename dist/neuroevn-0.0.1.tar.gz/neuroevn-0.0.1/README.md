```
# NeuroEVN

Package for applying NeuroEvolution strategies
```