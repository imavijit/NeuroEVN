def render():
    print("env is rendering")
